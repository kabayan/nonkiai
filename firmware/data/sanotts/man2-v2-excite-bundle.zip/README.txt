sanoTTS-jp モデル一式

run: voice-tail-man2-v2-excite-full-20261029（man2-v2-excite-full）

- model-int8.bin : W8A8 のモデル
- build-flags.json : ビルドフラグ

model のフラグは、このモデルを鳴らすファーム・ホスト合成で必ずそろえてください。食い違ってもエラーは出ずに、別の音になります。
build-flags.json の "model" と "cmdline" がそれです（idf.py にもホストの gcc 合成にも同じ -D を渡す）。
"board" は、この run の試聴に使った板の設定です（参考。モデルに結びつくものではありません）。
